# Backend

### Live Website : [eMart](https://shop-on-emart.herokuapp.com/)

## Don't forget to give this repo a ⭐ if you like this repo and want to appreciate the efforts

[![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/built-by-developers.svg)](https://forthebadge.com)
